<?php 
// We don't use the Collections on the front-end
include_once($_SERVER["DOCUMENT_ROOT"] . "/themes/curatescape/error/404.php");
?>