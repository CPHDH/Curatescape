<?php 
// We don't need to use the Geolocation plugin on the front-end
include_once($_SERVER["DOCUMENT_ROOT"] . "/themes/curatescape/error/404.php");
?>