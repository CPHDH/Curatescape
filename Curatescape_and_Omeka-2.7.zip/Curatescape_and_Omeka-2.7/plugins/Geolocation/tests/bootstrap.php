<?php

define('GEOLOCATION_DIR', dirname(dirname(__FILE__)));
require_once dirname(dirname(GEOLOCATION_DIR)) . '/application/tests/bootstrap.php';
require_once 'Geolocation_IntegrationHelper.php';
