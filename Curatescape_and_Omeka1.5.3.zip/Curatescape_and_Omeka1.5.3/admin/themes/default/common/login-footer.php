</div>
<div id="footer">
    <?php admin_plugin_footer(); ?>
    <p><a href="http://omeka.org" id="omeka-logo"><?php echo __('Powered by Omeka'); ?></a> | <?php echo __('Version %s', OMEKA_VERSION); ?></p>    
</div>
</div>
</body>
</html>