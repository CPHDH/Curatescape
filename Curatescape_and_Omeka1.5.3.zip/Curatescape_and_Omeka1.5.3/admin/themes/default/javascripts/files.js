jQuery(document).ready(function () {
    // Get rid of the add/remove buttons and 'Use HTML' checkbox.
    // This may be added back in future releases.
    jQuery('input.add-element, input.remove-element, label.use-html').remove();
});
