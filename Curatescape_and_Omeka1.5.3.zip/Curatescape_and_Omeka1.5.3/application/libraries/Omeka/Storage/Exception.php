<?php
class Omeka_Storage_Exception extends Exception {}
